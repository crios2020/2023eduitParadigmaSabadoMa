class Cliente:
    def __init__(self, cuit, direccion):
        self.cuit = cuit
        self.direccion = direccion

class ClientePyme(Cliente):
    def __init__(self, cuit, direccion, razonSocial):
        super().__init__(cuit, direccion)           #Llama al constructor de la clase padre
        self.razonSocial = razonSocial

mi_cliente = Cliente("12345678901", "Av. Siempreviva 742")
mi_cliente_pyme = ClientePyme("12345678901", "Av. Siempreviva 742", "Mi Empresa SA")