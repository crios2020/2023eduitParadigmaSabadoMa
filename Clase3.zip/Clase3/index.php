<?php
echo 'Hola Mundo';

//declaración de clases
class Auto{
    
    //atributos
    public $marca;
    public $modelo;
    public $color;
    public $velocidad;
    
    //métodos
    public function acelerar(){
        $this->velocidad=$this->velocidad+10;
    }
    
    public function frenar(){
        $this->velocidad=$this->velocidad-10;
    }
    
}//end class

$auto=new Auto();
$auto->marca="Dodge";
$auto->modelo="Caravan";
$auto->color="Rojo";
$auto->acelerar();              // 10
$auto->acelerar();              // 20
$auto->acelerar();              // 30
$auto->frenar();                // 20
echo chr(13);                   // Salto de linea
echo $auto->marca,' ',$auto->modelo,' ',$auto->color,' ',$auto->velocidad;


?>