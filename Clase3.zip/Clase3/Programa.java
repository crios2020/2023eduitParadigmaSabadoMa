public class Programa {
    public static void main(String[] args) {
        Alumno a1 = new Alumno();
        Alumno a2 = new Alumno("Juan", "Perez");

        a1.informar();
        a2.informar();
    }
}

class Alumno {
    // Atributos aquí
    private String nombre;
    private String apellido;

    // Constructores
    Alumno() {
        //Constructor vacio
    }

    public Alumno(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }

    // Métodos aquí
    public void informar() {
        System.out.println(nombre + " "+ apellido);
    }

    @Override
    public String toString() {
        return "Alumno [nombre=" + nombre + ", apellido=" + apellido + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

}