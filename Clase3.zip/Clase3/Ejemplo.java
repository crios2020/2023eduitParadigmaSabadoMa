public class Ejemplo {
    public static void main(String[] args) {

        int numero = 2;

        // Obtiene el cliente
        ClienteIndividuo cliente = new ClienteIndividuo("27014589");
        // Obtiene la caja de ahorro del cliente
        CajaDeAhorro cajaDeAhorro = cliente.obtenerCajaDeAhorro();
        // Realiza el deposito
        cajaDeAhorro.depositar(2500);

        cliente.obtenerCajaDeAhorro().depositar(2500);
        cliente.obtenerCajaDeAhorro().debitar(5000);

    }
}

class ClienteIndividuo {
    private String DNI;
    private CajaDeAhorro cajaDeAhorro = new CajaDeAhorro();

    public ClienteIndividuo(String DNI) {
        this.DNI = DNI;
    }

    public CajaDeAhorro obtenerCajaDeAhorro() {
        return cajaDeAhorro;
    }
}

class CajaDeAhorro {
    private double saldo;
    private double saldoDescubierto = 5000;

    public void depositar(double monto) {
        saldo = saldo + monto;
    }

    public void debitar(double monto) {
        if (saldo >= monto) {
            saldo = saldo - monto;
            System.out.println("Extraccion ok");
        } else {
            double montoExcedente = monto - saldo;
            if (montoExcedente <= saldoDescubierto) {
                saldo = 0;
                saldoDescubierto = saldoDescubierto - montoExcedente;
                System.out.println("Extraccion ok");
            } else {
                System.out.println("No hay fondos suficientes");
            }
        }
    }
}