public class Ejemplo2 {
    public static void main(String[] args) {
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente("66666","Lima 324");
        //cliente1.cuit="66666";
        //cliente1.direccion="Lima 324";
        //cliente1.razonSocial="Servicios y operaciones";
        cliente1.saludar();

        System.out.println("-- clientePyme1 --");
        ClientePyme clientePyme1=new ClientePyme("999999","Lavalle 2345","Todo Limpio srl");
        //clientePyme1.cuit="999999";
        //clientePyme1.direccion="Lavalle 2345";
        //clientePyme1.razonSocial="Todo Limpio srl";
        clientePyme1.saludar();

    }
}

class Cliente {

    // Atributos
    String cuit;
    String direccion;

    // Constructores
    //public Cliente(){}
    public Cliente(String cuit, String direccion) {
        this.cuit = cuit;
        this.direccion = direccion;
    }

    // Métodos
    void saludar() {
        System.out.println("Hola soy un cliente!");
    }

}

class ClientePyme extends Cliente {

    // Atributos - Los atributos heredados no se vuelven a codificar!
    String razonSocial;

    // Constructores
    public ClientePyme(String cuit, String direccion, String razonSocial) {
        super(cuit, direccion);             //llama al constructor de la clase padre
        this.razonSocial = razonSocial;
    }
    
    // Métodos
    // Método sobreescrito
    void saludar() {
        System.out.println("Hola soy un clientePyme!");
    }

}
