print('Hola Mundo!')

class Auto:
    velocidad=0
    def __init__(self, marca, modelo, color):
        self.marca = marca
        self.modelo = modelo
        self.color = color

    def acelerar(self, kilometros):
        self.velocidad += kilometros

    def frenar(self, kilometros):
        self.velocidad -= kilometros

mi_auto = Auto("Toyota", "Corolla", "Rojo")

mi_auto.acelerar(20)
mi_auto.frenar(10)

print(mi_auto.marca,' ',mi_auto.modelo,' ',mi_auto.color,' ',mi_auto.velocidad)
