#linea de comentarios
print("Hola Mundo")

#declaración de clases
class Auto:
    
    #atributos
    marca=""
    modelo=""
    color=""
    velocidad=0

    #métodos
    def acelerar():
        velocidad=velocidad+10
    
    def frenar():
        velocidad=velocidad-10

#Primero va la clase , luego los objetos
print("-- auto1 --")
auto1 = Auto()