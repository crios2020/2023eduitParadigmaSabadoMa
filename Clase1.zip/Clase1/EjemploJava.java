public class EjemploJava{
    public static void main(String[] args) {
        //Clase 1 de paradigma de objetos
        System.out.println("Hola Mundo!!");
        
        //Creamos objetos de la clase Auto
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();      //se construye un objeto de la clase Auto
        
        //le colocamos estado al objeto
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Negro";
        
        //usamos sus métodos
        auto1.acelerar();       //10
        auto1.acelerar();       //20
        auto1.acelerar();       //30
        auto1.frenar();         //20
        
        //imprimir el estado del objeto
        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Toro";
        auto2.color="Rojo";
        auto2.acelerar();
        System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);
        
        
        
    }
}

//declaración de clase
class Auto{
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //métodos
    void acelerar(){
        velocidad=velocidad+10;
    }
    
    void frenar(){
        velocidad=velocidad-10;
    }
    
}//end class Auto

class Empleado{
	//atributos
	int nroLegajo
	String nombre;
	Auto auto;
}
