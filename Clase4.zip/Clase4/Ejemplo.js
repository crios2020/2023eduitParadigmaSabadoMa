class Auto {
	
  constructor(marca, modelo, color, velocidad) {
    this.marca = marca;
    this.modelo = modelo;
    this.color = color;
    this.velocidad = velocidad;
  }

  acelerar() {
    this.velocidad += 10;
    console.log(`El ${this.marca} ${this.modelo} aceleró a ${this.velocidad} km/h`);
  }

  frenar() {
    this.velocidad -= 10;
    console.log(`El ${this.marca} ${this.modelo} frenó a ${this.velocidad} km/h`);
  }
}

// Ejemplo de uso:
const miAuto = new Auto("Ford", "Mustang", "Rojo", 0);
miAuto.acelerar(); // El Ford Mustang aceleró a 10 km/h
miAuto.acelerar(); // El Ford Mustang aceleró a 20 km/h
miAuto.frenar(); // El Ford Mustang frenó a 10 km/h
