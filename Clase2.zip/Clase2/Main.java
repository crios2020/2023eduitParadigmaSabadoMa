import javax.swing.JOptionPane;

public class Main {                                                 //Declaración de clase principal
    public static void main(String[] args) {                        //punto de entrada del proyecto
    
        String black="\033[30m"; 
        String red="\033[31m"; 
        String green="\033[32m"; 
        String yellow="\033[33m"; 
        String blue="\033[34m"; 
        String purple="\033[35m"; 
        String cyan="\033[36m"; 
        String white="\033[37m";
        String reset="\u001B[0m";
    
        System.out.println(red+"Paradigma Clase 2!"+reset);
        
        //Crear un objeto simulado(MOCK)
        Auto auto1=new Auto();
        auto1.marca="VW";
        auto1.modelo="Gol";
        auto1.color="Blanco";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        auto1.acelerar(25);         //45
        auto1.acelerar(130);        //100
        //auto1.velocidad=150;        //150
        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
        
        auto1.imprimirVelocidad();
        System.out.println("Velocidad: "+auto1.obtenerVelocidad());
        
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto1.obtenerVelocidad());

    }//end main
}//end main class

class Auto{                                                         //Declaración de clase
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //Métodos
    void acelerar(){
        velocidad=velocidad+10;
        if(velocidad>100) velocidad=100;
    }
    void acelerar(int kilometros){                                  //Método sobrecargado con ingreso de parámetros
        velocidad=velocidad+kilometros;
        if(velocidad>100) velocidad=100;
    }
    void frenar(){
        velocidad=velocidad-10;
    }
    void imprimirVelocidad(){                                   //Método sin devolución de parámetros
        System.out.println(velocidad);
    }
    int obtenerVelocidad(){
        return velocidad;                                       //retorna la velocidad    
    }
}//end class


