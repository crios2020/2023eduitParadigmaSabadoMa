public class Parte2 {
    public static void main(String[] args) {
        System.out.println("Paradigma Clase 2 Parte 2");

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(50000);
        cuenta1.depositar(120000);
        cuenta1.debitar(30000);
        //cuenta1.saldo=4000000;
        System.out.println(cuenta1.getEstado());

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1,"Ariel",new Cuenta(2,"arg$"));
        cliente1.getCuenta().depositar(56000);
        cliente1.getCuenta().depositar(33000);
        cliente1.getCuenta().debitar(24000);
        System.out.println(cliente1.getEstado());

        System.out.println("-- gabriel y ana --");
        Cliente gabriel=new Cliente(2,"Gabriel",new Cuenta(2, "arg4"));
        gabriel.getCuenta().depositar(200000);
        Cliente ana=new Cliente(3, "Ana", gabriel.getCuenta());
        ana.getCuenta().debitar(100000);

        System.out.println(gabriel.getEstado());
        System.out.println(ana.getEstado());
        



    }
}

class Cliente{
    private int nro;
    private String nombre;
    private Cuenta cuenta;

    //Constructores
    //Los clientes pueden ser creados sin una cuenta
    // public Cliente(int nro, String nombre){
    //     this.nro=nro;
    //     this.nombre=nombre;
    // }

    //Todos los clientes tiene cuentas
    //Una cuenta puede pertencer a más de un cliente
    public Cliente(int nro, String nombre, Cuenta cuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.cuenta=cuenta;
    }

    //Todos los clientes tiene cuentas
    //Una cuenta solo pertenece a un cliente
    public Cliente(int nro, String nombre, int nroCuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.cuenta=new Cuenta(nroCuenta,"arg$");
    }

    public String getEstado(){
        return nro+", "+nombre+", "+cuenta.getEstado();
    }

    public Cuenta getCuenta(){
        return cuenta;
    }
}

class Cuenta{
    private int nro;
    private String moneda;
    private double saldo;

    //método constructor
    public Cuenta(int nro, String moneda){
        this.nro=nro;
        this.moneda=moneda;
    }

    public void depositar(double monto){
        this.saldo=this.saldo+monto;
    }

    public void debitar(double monto){
        if(this.saldo>=monto){
            this.saldo=this.saldo-monto;
        }else{
            System.out.println("Saldo Insuficiente!!");
        }
    }

    public String getEstado(){
        return nro+", "+moneda+", "+saldo;
    }
}
